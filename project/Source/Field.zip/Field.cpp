#include "Field.h"
#include <vector>
#include "Player.h"
#include "CsvReader.h"
#include "Greenslime.h"
#include "Redslime.h"

using namespace std;

const int ts = 64;
const int tf = 64 * 7;

vector<vector<int>> maps;

Field::Field(int stage)
{
	char filename[60];
	sprintf_s<60>(filename, "data/map%d.csv", stage);
	// CSV����ǂ�ŁAmaps�����
	CsvReader* csv = new CsvReader(filename);
	int lines = csv->GetLines(); // �c�̍s��
	maps.resize(lines); // maps�̍s����csv�ɍ��킹��
	for (int y = 0; y < lines; y++) {
		int cols = csv->GetColumns(y); // ���̍s�̉��̐�
		maps[y].resize(cols); // maps[y]�̗񐔂�csv�ɍ��킹��
		for (int x = 0; x < cols; x++) {
			int num = csv->GetInt(y, x);
			maps[y][x] = num;
		}
	}
	delete csv;

	hImage = LoadGraph("data/image/bgchar.png");

	bgImage = LoadGraph("data/image/BackGround.png");  // �p�X�͕K�v�ɉ����ĕύX
	GetGraphSize(bgImage, &bgWidth, nullptr);
	bgScrollX = 0;

	scrollX = 0;
	for (int y = 0; y < maps.size(); y++) {
		for (int x = 0; x < maps[y].size(); x++) {
			if (maps[y][x] == 2) {
				new Player(x * 64, y * 64);
			}
			if (maps[y][x] == 3) {
				new Greenslime(x * 64, y * 64);
			}
			if (maps[y][x] == 4) {
				new Redslime(x * 64, y * 64);
			}
		}
	}
}

Field::~Field()
{
}

void Field::Update()
{
	Player* player = FindGameObject<Player>();

	if (player && !player->IsDead()) {
		scrollX += 7; //�����X�N���[���̏ꍇ
		bgScrollX += 7;    // �w�i�p�X�N���[��
	}
	

	// �w�i�������[�v������
	if (bgScrollX >= bgWidth) {
		bgScrollX -= bgWidth;
	}
}

void Field::Draw()
{
	DrawGraph(-bgScrollX, 0, bgImage, TRUE);
	DrawGraph(bgWidth - bgScrollX, 0, bgImage, TRUE);

	for (int y = 0; y < maps.size(); y++) {
		for (int x = 0; x < maps[y].size(); x++) {
			if (maps[y][x] == 1) {
				DrawRectGraph(x * 64 - scrollX, y * 64, 0, 32, 64, 64, hImage, 1);
			}
		}
	}
}

bool Field::IsBlock(int px, int py)
{
	if (py < 0 || py >= maps.size())return false;
	if (px < 0 || px >= maps[py].size())return false;

	return maps[py][px] == 1;
}

int Field::HitCheckRight(int px, int py)
{
	if (py < 0)
		return 0;
	int x = px / 64;
	int y = py / 64;
	if (!IsBlock(x, y))return 0;
	return px % 64 + 1;
	return 0;
}

int Field::HitCheckLeft(int px, int py)
{
	if (py < 0)
		return 0;
	int x = px / 64;
	int y = py / 64;
	if (!IsBlock(x, y))return 0;
	return 64 - px % 64;
	return 0;
}

int Field::HitCheckUp(int px, int py)
{
	if (py < 0)
		return 0;
	int x = px / 64;
	int y = py / 64;
	if (!IsBlock(x, y))return 0;
	return 64 - py % 64;
	return 0;
}

int Field::HitCheckDown(int px, int py)
{
	if (py < 0) {
		return 0;
	}
	int x = px / 64;
	int y = py / 64;
	if (!IsBlock(x, y))return 0;
	return py % 64 + 1;
	return 0;
}

bool Field::OutOfMap(int px, int py)
{
	if (py > 0 + 64 * maps.size()) {
		return true;
	}
	return false;

}



int Field::GetScrollX() const { return scrollX; }
void Field::SetScrollX(int sx) { scrollX = sx; }

