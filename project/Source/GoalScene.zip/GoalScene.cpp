#include "GoalScene.h"
#include "DxLib.h"
#include "../Library/SceneManager.h"
#include<assert.h>
#include<vector>

GoalScene::GoalScene()
{
	hImage = LoadGraph("data/image/3Dchara.png");
	assert(hImage != -1);

	bgImage = LoadGraph("data/image/BGgoal.png");
	assert(bgImage != -1);

	gmImage = LoadGraph("data/image/greenmidasi.png");
	assert(gmImage != -1);

	glImage = LoadGraph("data/image/GameClear.png");
	assert(glImage != -1);

	fadeAlpha = 255;

	fonthandle = CreateFontToHandle(NULL, 32, 3);
	blinkTimer = 0;
}

GoalScene::~GoalScene()
{
	DeleteGraph(bgImage);
	DeleteGraph(hImage);
	DeleteGraph(gmImage);
	DeleteGraph(glImage);
}

void GoalScene::Update()
{
	// �t�F�[�h�C��
	if (fadeAlpha > 0) {
		fadeAlpha -= 5;   // �� ���l��ς���Ƒ�������
		if (fadeAlpha < 0) fadeAlpha = 0;
		return; // �t�F�[�h���̓L�[���͂𖳌��ɂ���
	}

	if (CheckHitKey(KEY_INPUT_T)||CheckHitKey(KEY_INPUT_O)) {
		SceneManager::ChangeScene("TITLE");
	}
}

void GoalScene::Draw()
{
	DrawExtendGraph(0, 0, 1280, 720, bgImage,TRUE);

	DrawRectRotaGraph(600,150, 0, 0, 1354, 303, 0.75f, 0.0, glImage, TRUE);

	DrawRectRotaGraph(570, 630, 0, 0, 591, 95, 0.75f, 0.0, gmImage, TRUE);
	
	DrawRectRotaGraph(
		600,
		400,
		0, 0,           // �؂���J�n
		1024, 1536,     // ���摜�T�C�Y
		0.25f,          // �k����
		0.0,
		hImage,
		TRUE
	);


	blinkTimer++;
	if ((blinkTimer / 45) % 2 == 0)	{
		DrawStringToHandle(460, 610, "T�L�[�F�^�C�g��", GetColor(255, 255, 255), fonthandle);
	}

	// �t�F�[�h�p�����
	if (fadeAlpha > 0) {
		SetDrawBlendMode(DX_BLENDMODE_ALPHA, fadeAlpha);
		DrawBox(0, 0, 1280, 720, GetColor(0, 0, 0), TRUE);
		SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
	}
}
