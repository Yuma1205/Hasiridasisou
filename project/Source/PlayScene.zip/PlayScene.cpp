#include "PlayScene.h"
#include "Player.h"
#include "Field.h"
#include "Common.h"
#include "../Library/SceneManager.h"
#include "../Library/ObjectManager.h"
#include "GameOver.h"

int PlayScene::lives = 0;

PlayScene::PlayScene()
{
    m_readyGo = new ReadyGoManager();
    int stage = SceneManager::GetNextStage();
    new Field(stage);

    isSceneChanging = false;
    restartTimer = 0;

    // ���ŏ��́u���v����t�F�[�h�C��
    fadeAlpha = 255;
    fadeColor = GetColor(255, 255, 255);

    lives = 3;

    hLifeImage = LoadGraph("data/image/Chara.png");
    hBGM = LoadSoundMem("data/Sound/stageBGM1.mp3");
    ChangeVolumeSoundMem(160, hBGM);

}

PlayScene::~PlayScene()
{
    if (m_readyGo) {
        delete m_readyGo;
        m_readyGo = nullptr;
    }

    DeleteGraph(hLifeImage);

    StopSoundMem(hBGM);
    DeleteSoundMem(hBGM);

    ObjectManager::DeleteAll();
}

void PlayScene::Reset()
{
    ObjectManager::DeleteAll();

    isSceneChanging = false;
    restartTimer = 0;

    // �����X�^�[�g���́u���v�ɃZ�b�g
    fadeAlpha = 255;
    fadeColor = GetColor(255, 255, 255);

    int stage = SceneManager::GetNextStage();
    new Field(stage);

    StopSoundMem(hBGM);

    if (m_readyGo) {
        delete m_readyGo;
    }
    m_readyGo = new ReadyGoManager();

    StopSoundMem(hBGM);
}

void PlayScene::Update()
{

    if (!isSceneChanging && fadeAlpha > 0) {
        fadeAlpha -= 5;
        if (fadeAlpha < 0) {
            fadeAlpha = 0;
        }
    }

    if (fadeAlpha == 0 && !m_readyGo->IsStarted()) {
        m_readyGo->Start();
    }

    // ReadyGo���o�̍X�V
    m_readyGo->Update();
    if (m_readyGo->IsActive()) {
        return;
    }
    if (!isSceneChanging && CheckSoundMem(hBGM) == 0 && lives > 0) {
        PlaySoundMem(hBGM, DX_PLAYTYPE_LOOP);
    }
    if (isSceneChanging) {
        restartTimer++;

        // ��ʂ��Â�����i���X�^�[�g���o�j
        fadeAlpha = 255 * restartTimer / 120;
        if (fadeAlpha > 255) { fadeAlpha = 255; }

        // 2�b�o�����烊�Z�b�g
        if (restartTimer == 120) {
            lives--; // �c�@�����炷
            Reset(); // ���X�^�[�g
        }

        return; 
    }

    // �ʏ�̃Q�[���X�V
    ObjectManager::Update();

    // �v���C���[�̎��S�`�F�b�N
    Player* player = FindGameObject<Player>();
    if (player != nullptr) {
        if (player->IsDead() && player->IsAnimEnd() && lives > 0) {

            if (lives == 1) {
                lives--;        // 0�ɂ���
                new GameOver(); // �����ɕ�����\��

                StopSoundMem(hBGM);
            }
            else {

                isSceneChanging = true;
                restartTimer = 0;

                // �t�F�[�h�A�E�g�̐F���u���v�ɃZ�b�g
                fadeColor = GetColor(0, 0, 0);

                StopSoundMem(hBGM);
            }
        }
    }

    // �f�o�b�O�p
    if (CheckHitKey(KEY_INPUT_O)) {
        lives = 0;
        SceneManager::ChangeScene("TITLE");
    }
}

void PlayScene::Draw()
{
    DrawString(0, 0, "PLAY SCENE", GetColor(255, 255, 255));

    ObjectManager::Draw();
    m_readyGo->Draw();

    // �c�@�A�C�R���̕`��
    for (int i = 0; i < lives; i++) {
        int srcX = 128;
        int srcY = 192;
        int drawX = 20 + (i * 50);
        int drawY = 20;

        DrawRectRotaGraph(
            drawX + 24, drawY + 24, srcX, srcY, 64, 64, 0.75, 0.0,
            hLifeImage, TRUE, TRUE
        );
    }

    // ���t�F�[�h�`��
    if (fadeAlpha > 0) {
        int w, h;
        GetDrawScreenSize(&w, &h);
        SetDrawBlendMode(DX_BLENDMODE_ALPHA, fadeAlpha);

        // �w�肳�ꂽ�F�i���܂��͍��j�œh��Ԃ�
        DrawBox(0, 0, w, h, fadeColor, TRUE);

        SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
    }
}